
<?php $__env->startSection('content'); ?>
<div class="row">
<section class="content">
	 	 <div class="col-md-8 col-md-offset-2">
	 	 	 <?php if(count($errors) > 0): ?>
	 	 	 <div class="alert alert-danger">
	 	 	 	 <strong>Error!</strong> Revise los campos obligatorios.<br><br>
	 	 	 	 <ul>
	 	 	 	 	 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 	 	 	 	 <li><?php echo e($error); ?></li>
	 	 	 	 	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 	 	 	 </ul>
	 	 	 </div>
	 	 	 <?php endif; ?>
	 	 	 <?php if(Session::has('success')): ?>
	 	 	 <div class="alert alert-info">
	 	 	 	 <?php echo e(Session::get('success')); ?>

	 	 	 </div>
	 	 	 <?php endif; ?>
	 	 	 <div class="panel panel-default">
	 	 	 	 <div class="panel-heading">
	 	 	 	 	 <h3 class="panel-title">Nuevo Calzado</h3>
	 	 	 	 </div>
	 	 	 	 <div class="panel-body">	 	 	 	 	 

	 	 	 	 	 <div class="table-container">
	 	 	 	 	 	 <form method="POST" action="<?php echo e(route('calzado.update',
$calzado->idcalzado)); ?>" role="form">
	 	 	 	 	 	 	 <?php echo e(csrf_field()); ?>

<input name="_method" type="hidden"
value="PATCH">
	 	 	 	 	 	 	 <div class="row">
	 	 	 	 	 	 	 	 <div class="col-xs-6 col-sm-6 colmd-6">
	 	 	 	 	 	 	 	 	 <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="calzado" id="calzado" class="form-control input-sm" value="<?php echo e($calzado->calzado); ?>">
	 	 	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 	 </div>
<div class="col-xs-6 col-sm-6 colmd-6">
	 	 	 	 	 	 	 	 	 <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="tipo" id="tipo" class="form-control input-sm" value="<?php echo e($calzado->tipo); ?>">
	 	 	 	 	 	 	 	 	 </div>

	 	 	 	 	 	 	 	 </div>
                                        <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="color" id="color" class="form-control input-sm" value="<?php echo e($calzado->color); ?>">
	 	 	 	 	 	 	 	 	 </div>

                                             <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="talla" id="talla" class="form-control input-sm" value="<?php echo e($calzado->talla); ?>">
	 	 	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 
<div class="row">
	 	 	 	 	 	 	 	 <div class="col-xs-6 col-sm-6 colmd-6">
	 	 	 	 	 	 	 	 	 <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="marca" id="marca" class="form-control input-sm" value="<?php echo e($calzado->marca); ?>">
	 	 	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 	 </div>
<div class="col-xs-6 col-sm-6 colmd-6">
	 	 	 	 	 	 	 	 	 <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="genero" id="genero" class="form-control input-sm" value="<?php echo e($calzado->genero); ?>">
	 	 	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 	 </div>
                                        <div class="col-xs-6 col-sm-6 colmd-6">
	 	 	 	 	 	 	 	 	 <div class="form-group">
	 	 	 	 	 	 	 	 	 	 <input type="text"
name="edades" id="edades" class="form-control input-sm" value="<?php echo e($calzado->edades); ?>">
	 	 	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 	 </div>
<div class="row">
	 	 	 	 	 	 	 	 <div class="col-xs-12 col-sm-12 colmd-12">
	 	 	 	 	 	 	 	 	 <input type="submit"
value="Actualizar" class="btn btn-success btn-block">
<a
href="<?php echo e(route('calzado.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
	 	 	 	 	 	 	 	 </div>	 

	 	 	 	 	 	 	 </div>
	 	 	 	 	 	 </form>
	 	 	 	 	 </div>
	 	 	 	 </div>
	 	 	 </div>
	 	 </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\3C24A - 2021\Aplicaciones en Internet\laravelcrudlab12\resources\views/Calzado/Cedit.blade.php ENDPATH**/ ?>