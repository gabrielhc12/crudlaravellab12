
<?php $__env->startSection('content'); ?>
<div class="row">
 <section class="content">
 <div class="col-md-8 col-md-offset-2">
 <div class="panel panel-default">
 <div class="panel-body">
 <div class="pull-left"><h3>Lista Calzados</h3></div>
 <div class="pull-right">
 <div class="btn-group">
 <a href="<?php echo e(route('calzado.create')); ?>" class="btn btn-info" >Añadir calzado</a>
 </div>
 </div>
 <div class="table-container">
 <table id="mytable" class="table table-bordred table-striped">
 <thead>
 <th>Nro. Calzado</th>
 <th>Calzado</th>
 <th>Tipo</th>
 <th>Color</th>
 <th>Talla</th>
 <th>Marca</th>
 <th>Genero</th>
 <th>Edades</th>
 </thead>
 <tbody>
 <?php if($calzados->count()): ?>
 <?php $__currentLoopData = $calzados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calzado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
 <td><?php echo e($calzado->idcalzado); ?></td>
 <td><?php echo e($calzado->calzado); ?></td>
 <td><?php echo e($calzado->tipo); ?></td>
 <td><?php echo e($calzado->color); ?></td>
 <td><?php echo e($calzado->talla); ?></td>
 <td><?php echo e($calzado->marca); ?></td>
 <td><?php echo e($calzado->genero); ?></td>
 <td><?php echo e($calzado->edades); ?></td>
 <td><a class="btn btn-primary btn-xs" href="<?php echo e(action('CalzadoController@edit', $calzado->idcalzado)); ?>" ><span class="glyphicon glyphicon-pencil"></span></a></td>
 <td>
 <form action="<?php echo e(action('CalzadoController@destroy', $calzado->idcalzado)); ?>" method="post">
 <?php echo e(csrf_field()); ?>

 <input name="_method" type="hidden" value="DELETE">
 <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon
glyphicon-trash"></span></button>
 </td>
 </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php else: ?>
 <tr>
 <td colspan="8">No hay registro !!</td>
 </tr>
 <?php endif; ?>
 </tbody>
 </table>
 </div>
 </div>
 <?php echo e($calzados->links()); ?>

 </div>
 </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\3C24A - 2021\Aplicaciones en Internet\laravelcrudlab12\resources\views/calzado.blade.php ENDPATH**/ ?>