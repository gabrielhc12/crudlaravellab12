
<?php $__env->startSection('content'); ?>
<center>
<a href="<?php echo e(route('calzado.index')); ?>" class="btn btn-info" >Click Aqui Para Administrar Los Calzados</a>
<br>
<br>
</center>
<div class="row">
 <section class="content">
 <div class="col-md-8 col-md-offset-2">
 <div class="panel panel-default">
 <div class="panel-body">
 <div class="pull-left"><h3>Ventas</h3></div>
 <div class="pull-right">
 <div class="btn-group">
 <a href="<?php echo e(route('venta.create')); ?>" class="btn btn-info" >Añadir Venta</a>
 </div>
 </div>
 <div class="table-container">
 <table id="mytable" class="table table-bordred table-striped">
 <thead>
 <th>Nro. Venta</th>
 <th>Nro. Calzado</th>
 <th>Tipo de Pago</th>
 <th>Monto (/s.)</th>
 <th>Fecha de venta</th>
 </thead>
 <tbody>
 <?php if($venta->count()): ?>
 <?php $__currentLoopData = $venta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
 <td><?php echo e($v->idventa); ?></td>
 <td><?php echo e($v->idcalzado); ?></td>
 <td><?php echo e($v->tipo_pago); ?></td>
 <td><?php echo e($v->monto_pago); ?></td>
 <td><?php echo e($v->created_at); ?></td>
 <td><a class="btn btn-primary btn-xs" href="<?php echo e(action('App\Http\Controllers\VentaController@edit', $v->idventa)); ?>" >
 <span class="glyphicon glyphicon-pencil"></span></a></td>
 <td>
 <form action="<?php echo e(action('App\Http\Controllers\VentaController@destroy', $v->idventa)); ?>" method="post">
 <?php echo e(csrf_field()); ?>

 <input name="_method" type="hidden" value="DELETE">
 <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon
glyphicon-trash"></span></button>
 </td>
 </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php else: ?>
 <tr>
 <td colspan="8">No hay registro !!</td>
 </tr>
 <?php endif; ?>
 </tbody>
 </table>
 </div>
 </div>
 <?php echo e($venta->links()); ?>

 </div>
 </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\3C24A - 2021\Aplicaciones en Internet\laravelcrudlab12\resources\views/Venta/venta.blade.php ENDPATH**/ ?>