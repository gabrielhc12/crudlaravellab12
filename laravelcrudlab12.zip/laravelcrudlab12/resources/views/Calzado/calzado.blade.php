@extends('layouts.layout')
@section('content')
<center>
<a href="{{ route('venta.index') }}" class="btn btn-info" >Click Aqui Para Administrar Las Ventas</a>
<br>
<br>
</center>

<div class="row">
 <section class="content">
 <div class="col-md-8 col-md-offset-2">
 <div class="panel panel-default">
 <div class="panel-body">
 <div class="pull-left"><h3>Listado de Calzados</h3></div>
 <div class="pull-right">
 <div class="btn-group">
 <a href="{{ route('calzado.create') }}" class="btn btn-info" >Añadir calzado</a>
 </div>
 </div>
 <div class="table-container">
 <table id="mytable" class="table table-bordred table-striped">
 <thead>
 <th>Nro. Calzado</th>
 <th>Calzado</th>
 <th>Tipo</th>
 <th>Color</th>
 <th>Talla</th>
 <th>Marca</th>
 <th>Genero</th>
 <th>Edades</th>
 </thead>
 <tbody>
 @if($calzados->count())
 @foreach($calzados as $calzado)
 <tr>
 <td>{{$calzado->idcalzado}}</td>
 <td>{{$calzado->calzado}}</td>
 <td>{{$calzado->tipo}}</td>
 <td>{{$calzado->color}}</td>
 <td>{{$calzado->talla}}</td>
 <td>{{$calzado->marca}}</td>
 <td>{{$calzado->genero}}</td>
 <td>{{$calzado->edades}}</td>
 <td><a class="btn btn-primary btn-xs" href="{{action('App\Http\Controllers\CalzadoController@edit', $calzado->idcalzado)}}" >
 <span class="glyphicon glyphicon-pencil"></span></a></td>
 <td>
 <form action="{{action('App\Http\Controllers\CalzadoController@destroy', $calzado->idcalzado)}}" method="post">
 {{csrf_field()}}
 <input name="_method" type="hidden" value="DELETE">
 <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon
glyphicon-trash"></span></button>
 </td>
 </tr>
 @endforeach
 @else
 <tr>
 <td colspan="8">No hay registro !!</td>
 </tr>
 @endif
 </tbody>
 </table>
 </div>
 </div>
 {{ $calzados->links() }}
 </div>
 </div>
</section>
@endsection