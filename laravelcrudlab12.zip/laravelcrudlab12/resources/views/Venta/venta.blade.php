@extends('layouts.layout')
@section('content')
<center>
<a href="{{ route('calzado.index') }}" class="btn btn-info" >Click Aqui Para Administrar Los Calzados</a>
<br>
<br>
</center>
<div class="row">
 <section class="content">
 <div class="col-md-8 col-md-offset-2">
 <div class="panel panel-default">
 <div class="panel-body">
 <div class="pull-left"><h3>Ventas</h3></div>
 <div class="pull-right">
 <div class="btn-group">
 <a href="{{ route('venta.create') }}" class="btn btn-info" >Añadir Venta</a>
 </div>
 </div>
 <div class="table-container">
 <table id="mytable" class="table table-bordred table-striped">
 <thead>
 <th>Nro. Venta</th>
 <th>Nro. Calzado</th>
 <th>Tipo de Pago</th>
 <th>Monto (/s.)</th>
 <th>Fecha de venta</th>
 </thead>
 <tbody>
 @if($venta->count())
 @foreach($venta as $v)
 <tr>
 <td>{{$v->idventa}}</td>
 <td>{{$v->idcalzado}}</td>
 <td>{{$v->tipo_pago}}</td>
 <td>{{$v->monto_pago}}</td>
 <td>{{$v->created_at}}</td>
 <td><a class="btn btn-primary btn-xs" href="{{action('App\Http\Controllers\VentaController@edit', $v->idventa)}}" >
 <span class="glyphicon glyphicon-pencil"></span></a></td>
 <td>
 <form action="{{action('App\Http\Controllers\VentaController@destroy', $v->idventa)}}" method="post">
 {{csrf_field()}}
 <input name="_method" type="hidden" value="DELETE">
 <button class="btn btn-danger btn-xs" type="submit"><span class="glyphicon
glyphicon-trash"></span></button>
 </td>
 </tr>
 @endforeach
 @else
 <tr>
 <td colspan="8">No hay registro !!</td>
 </tr>
 @endif
 </tbody>
 </table>
 </div>
 </div>
 {{ $venta->links() }}
 </div>
 </div>
</section>
@endsection