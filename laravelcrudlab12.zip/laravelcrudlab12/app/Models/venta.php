<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class venta extends Model
{
    protected $table = 'venta';
    protected $primaryKey = 'idventa'; 
    protected $fillable = ['idventa','idcalzado','tipo_pago','monto_pago',
    'created_at'];    
}
