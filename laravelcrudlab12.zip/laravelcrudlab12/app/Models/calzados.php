<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class calzados extends Model
{

    protected $primaryKey = 'idcalzado'; 

    protected $fillable = ['idcalzado','calzado','tipo','color'
    ,'talla','marca','genero','edades'];

}
